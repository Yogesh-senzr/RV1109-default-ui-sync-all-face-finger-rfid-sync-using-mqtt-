#include "SysSetupFrm.h"

#include "../SetupItemDelegate/CItemWidget.h"
#include "LanguageFrm.h"
#include "FillLightFrm.h"
#include "LuminanceFrm.h"
#include "VolumeFrm.h"
#include "LogPasswordChangeFrm.h"
#include "QRCodeFrm.h"
#include "SyncFunctionality.h"
#include "Helper/myhelper.h"

#include "Config/ReadConfig.h"
#include "OperationTipsFrm.h"
#include "DeviceInfo.h"

#include <QListWidget>
#include <QHBoxLayout>
#include <QApplication>
#include <QScreen>
#include <QDesktopWidget>
#include <QMouseEvent>
#include <QDebug>
#include <QListWidgetItem>
#include <QtConcurrent/QtConcurrent>
#include <QNetworkInterface>

class SysSetupFrmPrivate
{
    Q_DECLARE_PUBLIC(SysSetupFrm)
public:
    SysSetupFrmPrivate(SysSetupFrm *dd);
private:
    void InitUI();
    void InitData();
    void InitConnect();
private:
    //检测顶层窗口是否显示
    bool CheckTopState();
private:
    QListWidget *m_pListWidget;
private:
    LanguageFrm *m_pLanguageFrm;//语音设置
    LuminanceFrm *m_pLuminanceFrm;//亮度设置
    FillLightFrm *m_pFillLightFrm;//补光设置
    VolumeFrm *m_pVolumeFrm;//音量设置
    LogPasswordChangeFrm *m_pLogPasswordChangeFrm;//登陆密码修改
    QRCodeFrm *m_pQRCodeFrm;
private:
    SysSetupFrm *const q_ptr;
};

SysSetupFrmPrivate::SysSetupFrmPrivate(SysSetupFrm *dd)
    : q_ptr(dd)
{
    m_pQRCodeFrm = new QRCodeFrm(q_ptr); 
    this->InitUI();
    this->InitData();
    this->InitConnect();
}

SysSetupFrm::SysSetupFrm(QWidget *parent)
    : SettingBaseFrm(parent)
    , d_ptr(new SysSetupFrmPrivate(this))
{
    Q_D(SysSetupFrm);
    d->m_pLanguageFrm = new LanguageFrm(this);//语音设置
    d->m_pLuminanceFrm = new LuminanceFrm(this);//亮度设置
    d->m_pFillLightFrm = new FillLightFrm(this);//补光设置
    d->m_pVolumeFrm = new VolumeFrm(this);
    d->m_pLogPasswordChangeFrm = new LogPasswordChangeFrm(this);
    d->m_pQRCodeFrm = new QRCodeFrm(this);
}

SysSetupFrm::~SysSetupFrm()
{

}

void SysSetupFrmPrivate::InitUI()
{
    m_pListWidget = new QListWidget;
    QHBoxLayout *layout = new QHBoxLayout(q_func());
    layout->setSpacing(0);
    layout->setMargin(0);
    layout->addWidget(m_pListWidget);
}

void SysSetupFrmPrivate::InitData()
{
    int width = QApplication::desktop()->screenGeometry().width();
    int spacing = 0;
    switch(width)
    {
    case 480:spacing = 22; break;
    case 600:spacing = 22;break;
    case 720:spacing = 36;break;
    case 800:spacing = 0;break;
    }

    m_pListWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    QStringList listName;

    listName<<QObject::tr("AccessControlSettings")<<QObject::tr("MainUISettings")<<QObject::tr("TimeSetting")
    <<QObject::tr("StorageCapacity")<<QObject::tr("LoginPassword")<<QObject::tr("About");

    {   // Language Settings
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(QObject::tr("LanguageSettings"), ":/Images/SmallRound.png", QObject::tr("English"));
        m_pListWidget->addItem(pItem);
        if (width==480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }

    {   // Brightness Settings
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(QObject::tr("BrightnessSetting"), ":/Images/SmallRound.png", "10");
        m_pListWidget->addItem(pItem);
        if (width==480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }

    {   // Fill Light Settings
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(QObject::tr("FillLightSetting"), ":/Images/SmallRound.png", QObject::tr("Auto"));
        m_pListWidget->addItem(pItem);
        if (width==480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }

    {   // Volume Settings
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(QObject::tr("VolumeSetting"), ":/Images/SmallRound.png", "8");
        m_pListWidget->addItem(pItem);
        if (width==480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }

    // QR Code item before about
    {
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(QObject::tr("QR Enrollment"), ":/Images/SmallRound.png");
        m_pListWidget->addItem(pItem);
        if (width==480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }

    // Add the rest of the items from listName
    for(int i = 0; i < listName.count(); i++)
    {
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(listName.at(i), ":/Images/SmallRound.png");
        m_pListWidget->addItem(pItem);
        if (width==480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }

    {   // Sync Devices
        QListWidgetItem *pItem = new QListWidgetItem;
        CItemWidget *pItemWidget = new CItemWidget;
        pItemWidget->setAddSpacing(spacing);
        pItemWidget->setData(QObject::tr("Sync Devices"), ":/Images/SmallRound.png");
        m_pListWidget->addItem(pItem);
        if (width == 480)
            pItemWidget->setAddSpacing(120);
        m_pListWidget->setItemWidget(pItem, pItemWidget);
    }
    
}

void SysSetupFrmPrivate::InitConnect()
{
    QObject::connect(m_pListWidget, &QListWidget::itemClicked, q_func(), &SysSetupFrm::slotIemClicked);
}

bool SysSetupFrmPrivate::CheckTopState()
{
    if(!m_pLuminanceFrm->isHidden())
    {
        ((CItemWidget *)this->m_pListWidget->itemWidget(this->m_pListWidget->item(1)))->setRNameText(QString::number(m_pLuminanceFrm->getAdjustValue()));
        ReadConfig::GetInstance()->setLuminance_Value(m_pLuminanceFrm->getAdjustValue());
        m_pLuminanceFrm->hide();

        return true;
    }else if(!m_pVolumeFrm->isHidden())
    {
        ((CItemWidget *)this->m_pListWidget->itemWidget(this->m_pListWidget->item(3)))->setRNameText(QString::number(m_pVolumeFrm->getAdjustValue()));
        m_pVolumeFrm->hide();
        return true;
    }
    return false;
}

static QString LanguageIdexToSTR(const int &index)
{
    switch(index)
    {
    case 0:return QObject::tr("English");
    case 1:return QObject::tr("English");
    //case 2:return QObject::tr("日本語");
    //case 3:return QObject::tr("한글");
    }
    return QObject::tr("English");
}

static QString FillLightIndexToSTR(const int &index)
{
    switch(index)
    {
        case 0:return QObject::tr("NormallyClosed");//常闭
        case 1:return QObject::tr("NormallyOpen");//常开
        case 2:return QObject::tr("Auto");//自动
    }
    return QObject::tr("Auto");//自动
}

void SysSetupFrm::setEnter()
{
    qDebug() << "SysSetupFrm::setEnter() - COMPLETE STEP BY STEP VERSION - Start";
    
    Q_D(SysSetupFrm);
    if (!d) {
        qDebug() << "d_ptr is NULL in setEnter()!";
        return;
    }
    
    qDebug() << "Step 1: Testing ReadConfig access...";
    try {
        ReadConfig* config = ReadConfig::GetInstance();
        if (!config) {
            qDebug() << "ReadConfig::GetInstance() returned NULL!";
            return;
        }
        qDebug() << "Step 1: ReadConfig instance is valid";
    } catch (const std::exception& e) {
        qDebug() << "Step 1: Exception accessing ReadConfig:" << e.what();
        return;
    } catch (...) {
        qDebug() << "Step 1: Unknown exception accessing ReadConfig";
        return;
    }
    
    qDebug() << "Step 2: Testing form pointer validity...";
    if (!d->m_pLanguageFrm) {
        qDebug() << "Step 2: m_pLanguageFrm is NULL!";
        return;
    }
    if (!d->m_pLuminanceFrm) {
        qDebug() << "Step 2: m_pLuminanceFrm is NULL!";
        return;
    }
    if (!d->m_pFillLightFrm) {
        qDebug() << "Step 2: m_pFillLightFrm is NULL!";
        return;
    }
    if (!d->m_pVolumeFrm) {
        qDebug() << "Step 2: m_pVolumeFrm is NULL!";
        return;
    }
    qDebug() << "Step 2: All forms are valid";
    
    qDebug() << "Step 3: Testing list widget validity...";
    if (!d->m_pListWidget) {
        qDebug() << "Step 3: m_pListWidget is NULL!";
        return;
    }
    qDebug() << "Step 3: List widget item count:" << d->m_pListWidget->count();
    
    qDebug() << "Step 4: Testing ReadConfig methods one by one...";
    try {
        ReadConfig* config = ReadConfig::GetInstance();
        
        qDebug() << "Step 4a: Testing getLanguage_Mode()...";
        int languageMode = config->getLanguage_Mode();
        qDebug() << "Step 4a: Language mode retrieved:" << languageMode;
        
        qDebug() << "Step 4b: Testing getLuminance_Value()...";
        int brightnessValue = config->getLuminance_Value();
        qDebug() << "Step 4b: Brightness value retrieved:" << brightnessValue;
        
        qDebug() << "Step 4c: Testing getFillLight_Value()...";
        int fillLightValue = config->getFillLight_Value();
        qDebug() << "Step 4c: Fill light value retrieved:" << fillLightValue;
        
        qDebug() << "Step 4d: Testing getVolume_Value()...";
        int volumeValue = config->getVolume_Value();
        qDebug() << "Step 4d: Volume value retrieved:" << volumeValue;
        
        qDebug() << "Step 4: All ReadConfig methods work";
        
    } catch (const std::exception& e) {
        qDebug() << "Step 4: Exception in ReadConfig methods:" << e.what();
        return;
    } catch (...) {
        qDebug() << "Step 4: Unknown exception in ReadConfig methods";
        return;
    }
    
    qDebug() << "Step 5: Testing form setter methods...";
    try {
        ReadConfig* config = ReadConfig::GetInstance();
        
        qDebug() << "Step 5a: Testing LanguageFrm::setLanguageMode()...";
        int languageMode = config->getLanguage_Mode();
        d->m_pLanguageFrm->setLanguageMode(languageMode);
        qDebug() << "Step 5a: LanguageFrm::setLanguageMode() successful";
        
        qDebug() << "Step 5b: Testing LuminanceFrm::setAdjustValue()...";
        int brightnessValue = config->getLuminance_Value();
        d->m_pLuminanceFrm->setAdjustValue(brightnessValue);
        qDebug() << "Step 5b: LuminanceFrm::setAdjustValue() successful";
        
        qDebug() << "Step 5c: Testing FillLightFrm::setFillLightMode()...";
        int fillLightValue = config->getFillLight_Value();
        d->m_pFillLightFrm->setFillLightMode(fillLightValue);
        qDebug() << "Step 5c: FillLightFrm::setFillLightMode() successful";
        
        qDebug() << "Step 5d: Testing VolumeFrm::setAdjustValue()...";
        int volumeValue = config->getVolume_Value();
        d->m_pVolumeFrm->setAdjustValue(volumeValue);
        qDebug() << "Step 5d: VolumeFrm::setAdjustValue() successful";
        
        qDebug() << "Step 5: All form setter methods work";
        
    } catch (const std::exception& e) {
        qDebug() << "Step 5: Exception in form setter methods:" << e.what();
        return;
    } catch (...) {
        qDebug() << "Step 5: Unknown exception in form setter methods";
        return;
    }
    
    qDebug() << "Step 6: Testing CItemWidget access...";
    try {
        qDebug() << "Step 6a: Testing item 0 (Language)...";
        QListWidgetItem* item0 = d->m_pListWidget->item(0);
        if (!item0) {
            qDebug() << "Step 6a: item 0 is NULL!";
            return;
        }
        
        QWidget* widget0 = d->m_pListWidget->itemWidget(item0);
        if (!widget0) {
            qDebug() << "Step 6a: widget 0 is NULL!";
            return;
        }
        
        CItemWidget* cWidget0 = qobject_cast<CItemWidget*>(widget0);
        if (!cWidget0) {
            qDebug() << "Step 6a: Failed to cast widget 0 to CItemWidget!";
            return;
        }
        
        qDebug() << "Step 6a: Testing setRNameText on item 0...";
        cWidget0->setRNameText("Test Language");
        qDebug() << "Step 6a: setRNameText successful on item 0";
        
        qDebug() << "Step 6b: Testing item 1 (Brightness)...";
        QListWidgetItem* item1 = d->m_pListWidget->item(1);
        if (!item1) {
            qDebug() << "Step 6b: item 1 is NULL!";
            return;
        }
        
        QWidget* widget1 = d->m_pListWidget->itemWidget(item1);
        if (!widget1) {
            qDebug() << "Step 6b: widget 1 is NULL!";
            return;
        }
        
        CItemWidget* cWidget1 = qobject_cast<CItemWidget*>(widget1);
        if (!cWidget1) {
            qDebug() << "Step 6b: Failed to cast widget 1 to CItemWidget!";
            return;
        }
        
        qDebug() << "Step 6b: Testing setRNameText on item 1...";
        cWidget1->setRNameText("Test Brightness");
        qDebug() << "Step 6b: setRNameText successful on item 1";
        
        qDebug() << "Step 6c: Testing item 2 (Fill Light)...";
        QListWidgetItem* item2 = d->m_pListWidget->item(2);
        if (!item2) {
            qDebug() << "Step 6c: item 2 is NULL!";
            return;
        }
        
        QWidget* widget2 = d->m_pListWidget->itemWidget(item2);
        if (!widget2) {
            qDebug() << "Step 6c: widget 2 is NULL!";
            return;
        }
        
        CItemWidget* cWidget2 = qobject_cast<CItemWidget*>(widget2);
        if (!cWidget2) {
            qDebug() << "Step 6c: Failed to cast widget 2 to CItemWidget!";
            return;
        }
        
        qDebug() << "Step 6c: Testing setRNameText on item 2...";
        cWidget2->setRNameText("Test Fill Light");
        qDebug() << "Step 6c: setRNameText successful on item 2";
        
        qDebug() << "Step 6d: Testing item 3 (Volume)...";
        QListWidgetItem* item3 = d->m_pListWidget->item(3);
        if (!item3) {
            qDebug() << "Step 6d: item 3 is NULL!";
            return;
        }
        
        QWidget* widget3 = d->m_pListWidget->itemWidget(item3);
        if (!widget3) {
            qDebug() << "Step 6d: widget 3 is NULL!";
            return;
        }
        
        CItemWidget* cWidget3 = qobject_cast<CItemWidget*>(widget3);
        if (!cWidget3) {
            qDebug() << "Step 6d: Failed to cast widget 3 to CItemWidget!";
            return;
        }
        
        qDebug() << "Step 6d: Testing setRNameText on item 3...";
        cWidget3->setRNameText("Test Volume");
        qDebug() << "Step 6d: setRNameText successful on item 3";
        
        qDebug() << "Step 6: All CItemWidget access tests successful";
        
    } catch (const std::exception& e) {
        qDebug() << "Step 6: Exception in CItemWidget access:" << e.what();
        return;
    } catch (...) {
        qDebug() << "Step 6: Unknown exception in CItemWidget access";
        return;
    }
    
    qDebug() << "Step 7: Testing with actual configuration values...";
    try {
        ReadConfig* config = ReadConfig::GetInstance();
        
        // Language
        int languageMode = config->getLanguage_Mode();
        QString languageStr = LanguageIdexToSTR(languageMode);
        QListWidgetItem* langItem = d->m_pListWidget->item(0);
        CItemWidget* langWidget = static_cast<CItemWidget*>(d->m_pListWidget->itemWidget(langItem));
        langWidget->setRNameText(languageStr);
        qDebug() << "Step 7: Language configuration applied successfully";
        
        // Brightness
        int brightnessValue = config->getLuminance_Value();
        QString brightnessStr = QString::number(brightnessValue);
        QListWidgetItem* brightItem = d->m_pListWidget->item(1);
        CItemWidget* brightWidget = static_cast<CItemWidget*>(d->m_pListWidget->itemWidget(brightItem));
        brightWidget->setRNameText(brightnessStr);
        qDebug() << "Step 7: Brightness configuration applied successfully";
        
        // Fill Light
        int fillLightValue = config->getFillLight_Value();
        QString fillLightStr = FillLightIndexToSTR(fillLightValue);
        QListWidgetItem* fillItem = d->m_pListWidget->item(2);
        CItemWidget* fillWidget = static_cast<CItemWidget*>(d->m_pListWidget->itemWidget(fillItem));
        fillWidget->setRNameText(fillLightStr);
        qDebug() << "Step 7: Fill Light configuration applied successfully";
        
        // Volume
        int volumeValue = config->getVolume_Value();
        QString volumeStr = QString::number(volumeValue);
        QListWidgetItem* volItem = d->m_pListWidget->item(3);
        CItemWidget* volWidget = static_cast<CItemWidget*>(d->m_pListWidget->itemWidget(volItem));
        volWidget->setRNameText(volumeStr);
        qDebug() << "Step 7: Volume configuration applied successfully";
        
        qDebug() << "Step 7: All actual configuration values applied successfully";
        
    } catch (const std::exception& e) {
        qDebug() << "Step 7: Exception applying actual configuration:" << e.what();
        return;
    } catch (...) {
        qDebug() << "Step 7: Unknown exception applying actual configuration";
        return;
    }
    
    qDebug() << "SysSetupFrm::setEnter() - COMPLETE STEP BY STEP VERSION - End successfully";
}

void SysSetupFrm::setLeaveEvent()
{
    Q_D(SysSetupFrm);
	d->CheckTopState();	//点击离开时保存设置值
    if(!d->m_pLuminanceFrm->isHidden())d->m_pLuminanceFrm->hide();
    if(!d->m_pVolumeFrm->isHidden())d->m_pVolumeFrm->hide();
    QtConcurrent::run(ReadConfig::GetInstance(), &ReadConfig::setSaveConfig);
}

void SysSetupFrm::slotIemClicked(QListWidgetItem *item)
{
    Q_D(SysSetupFrm);
#ifdef SCREENCAPTURE  //ScreenCapture     
    grab().save(QString("/mnt/user/screenshot/%1.png").arg(this->metaObject()->className()),"png");  
#endif 
    int width = QApplication::desktop()->screenGeometry().width();    
    if(d->CheckTopState())
    {//不处理
        return;
    }
    else if(item == d->m_pListWidget->item(0))
    {//语言设置 (Language Settings)
        d->m_pLanguageFrm->exec();
        ReadConfig::GetInstance()->setLanguage_Mode(d->m_pLanguageFrm->getLanguageMode());
        ((CItemWidget *)d->m_pListWidget->itemWidget(d->m_pListWidget->item(0)))->setRNameText(LanguageIdexToSTR(ReadConfig::GetInstance()->getLanguage_Mode()));
    }
    else if(item == d->m_pListWidget->item(1))
    {//亮度设置 (Brightness Settings)
        d->m_pLuminanceFrm->show();
    }
    else if(item == d->m_pListWidget->item(2))
    {//补光设置 (Fill Light Settings)
        d->m_pFillLightFrm->exec();
        ReadConfig::GetInstance()->setFillLight_Value(d->m_pFillLightFrm->getFillLightMode());
        ((CItemWidget *)d->m_pListWidget->itemWidget(d->m_pListWidget->item(2)))->setRNameText(FillLightIndexToSTR(ReadConfig::GetInstance()->getFillLight_Value()));
    }
    else if(item == d->m_pListWidget->item(3))
    {//音量设置 (Volume Settings)
        d->m_pVolumeFrm->show();
    }
    else if(item == d->m_pListWidget->item(4))
    {//QR Code Enrollment
        QString serialNumber = DeviceInfo::getInstance()->getSerialNumber(); // Retrieve serial from DeviceInfo
        d->m_pQRCodeFrm->setSerialNumber();
        d->m_pQRCodeFrm->exec();
    }
    
    else if(item == d->m_pListWidget->item(5))
    {//Access Control Settings
        emit sigShowFrm(((CItemWidget *)d->m_pListWidget->itemWidget(item))->getNameText());
    }
    
    else if(item == d->m_pListWidget->item(6))
    {//Main UI Settings
        emit sigShowFrm(((CItemWidget *)d->m_pListWidget->itemWidget(item))->getNameText());
    }
    else if(item == d->m_pListWidget->item(7))
    {//Time Settings
        emit sigShowFrm(((CItemWidget *)d->m_pListWidget->itemWidget(item))->getNameText());
    }
    else if(item == d->m_pListWidget->item(8))
    {//Storage Capacity
        emit sigShowFrm(((CItemWidget *)d->m_pListWidget->itemWidget(item))->getNameText());
    }
    else if(item == d->m_pListWidget->item(9))
    {//Login Password
        if (width==480)
            d->m_pLogPasswordChangeFrm->setFixedSize(d->m_pLogPasswordChangeFrm->width()-40, d->m_pLogPasswordChangeFrm->height());
        d->m_pLogPasswordChangeFrm->show();
        int ret = d->m_pLogPasswordChangeFrm->exec();
        if(ret == 0)
            ReadConfig::GetInstance()->setLoginPassword(d->m_pLogPasswordChangeFrm->getNewPasw());
    }
    else if(item == d->m_pListWidget->item(10))
    {//About
        emit sigShowFrm(((CItemWidget *)d->m_pListWidget->itemWidget(item))->getNameText());
    }

    else if (item == d->m_pListWidget->item(11)) // Adjust index if necessary
    {
        SyncFunctionality::ShowSyncDialog();
    }

}

#ifdef SCREENCAPTURE  //ScreenCapture 
void SysSetupFrm::mouseDoubleClickEvent(QMouseEvent* event)
{
    grab().save(QString("/mnt/user/screenshot/%1.png").arg(this->metaObject()->className()),"png");    
}
#endif 
