#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QCheckBox>
#include <QSettings>
#include <QDebug>
#include "Config/ReadConfig.h"

class SyncFunctionality
{
public:
    static void ShowSyncDialog();
};

void SyncFunctionality::ShowSyncDialog()
{
    QDialog dialog;
    dialog.setWindowTitle("Device Synchronization");
    dialog.setFixedSize(400, 250);

    QVBoxLayout *layout = new QVBoxLayout(&dialog);
    
    QLabel *titleLabel = new QLabel("Device Synchronization:");
    titleLabel->setStyleSheet("font-size: 18px; font-weight: bold; color: #333;");
    layout->addWidget(titleLabel);

    // Sync Toggle Button
    QPushButton *syncButton = new QPushButton;
    syncButton->setCheckable(true);
    syncButton->setFixedSize(80, 40);

    // Read current sync state - force fresh read from config
    bool isSyncEnabled = ReadConfig::GetInstance()->getSyncEnabled() != 0;
    qDebug() << "SYNC_DIALOG: Initial sync state from singleton:" << isSyncEnabled;
    
    syncButton->setChecked(isSyncEnabled);
    
    // Function to update button appearance
    auto updateButtonStyle = [](QPushButton* button, bool enabled) {
        button->setStyleSheet(
            QString("QPushButton {"
                   "border-radius: 20px;"
                   "background-color: %1;"
                   "color: white;"
                   "}")
            .arg(enabled ? "#5cb85c" : "#d9534f")
        );
    };
    
    // Apply initial styling
    updateButtonStyle(syncButton, isSyncEnabled);

    QLabel *syncStatusLabel = new QLabel(isSyncEnabled ? "Enabled" : "Disabled");
    syncStatusLabel->setStyleSheet("font-size: 16px; color: #555;");

    QObject::connect(syncButton, &QPushButton::clicked, [syncButton, syncStatusLabel, updateButtonStyle]() {
        bool newState = syncButton->isChecked();
        qDebug() << "SYNC_DIALOG: Button clicked, new state:" << newState;
        
        syncStatusLabel->setText(newState ? "Enabled" : "Disabled");
        updateButtonStyle(syncButton, newState);
        
        // Save the state immediately using singleton
        qDebug() << "SYNC_DIALOG: Saving state to singleton...";
        ReadConfig::GetInstance()->setSyncEnabled(newState ? 1 : 0);
        
        // Force save to file immediately
        ReadConfig::GetInstance()->setSaveConfig();
        
        // Verify the state was saved by reading it back
        bool savedState = ReadConfig::GetInstance()->getSyncEnabled() != 0;
        qDebug() << "SYNC_DIALOG: State verification - requested:" << newState << "saved:" << savedState;
        
        if (savedState != newState) {
            qDebug() << "ERROR: SYNC_DIALOG: State was not saved correctly!";
        } else {
            qDebug() << "SUCCESS: SYNC_DIALOG: State saved correctly";
        }
    });

    // Layout for switch and label
    QHBoxLayout *toggleLayout = new QHBoxLayout;
    toggleLayout->addWidget(syncButton);
    toggleLayout->addWidget(syncStatusLabel);
    layout->addLayout(toggleLayout);

    // Back Button
    QPushButton *backButton = new QPushButton("Back");
    backButton->setStyleSheet(
        "padding: 10px; font-size: 16px; background-color:rgb(79, 116, 217); color: white; border-radius: 5px;"
    );

    QObject::connect(backButton, &QPushButton::clicked, [&]() {
        // Verify state before closing
        bool finalState = ReadConfig::GetInstance()->getSyncEnabled() != 0;
        qDebug() << "SYNC_DIALOG: Dialog closing - final sync state:" << finalState;
        dialog.close();
    });

    layout->addWidget(backButton);
    dialog.setLayout(layout);
    
    // Debug initial state
    qDebug() << "SYNC_DIALOG: Dialog opened - initial sync state:" << isSyncEnabled;
    
    dialog.exec();
    
    // Final debug after dialog closes
    bool finalState = ReadConfig::GetInstance()->getSyncEnabled() != 0;
    qDebug() << "SYNC_DIALOG: Dialog execution finished - final state:" << finalState;
}